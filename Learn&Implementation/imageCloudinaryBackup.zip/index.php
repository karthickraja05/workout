<?php 

ini_set('max_execution_time', 0); // 0 = Unlimited

class CloudinaryImageCopy
{
	public $imagesArr = [];

	public $folderLocation;

	public $baseUrl;

	public function __construct($name=null)
	{
		$this->imagesArr = $this->readFileData();		
		$this->folderLocation = $this->createFolder($name);
		$this->baseUrl = 'https://res.cloudinary.com/spiffy/image/upload/v1638420989/sample2/';
	}

	public function readFileData(){
		// Read Files and Convert into Array
		$data = file_get_contents('images.txt');
		return preg_split('/\r\n|\r|\n/', $data);
	}

	// Create Backup Folder
	public function createFolder($name){
		$name = $name ? $name : 'backup_'.uniqid();
		if(!file_exists($name)){
			mkdir($name);	
		}
		
		exec('chmod -R 777 *');
		return $name;
	}

	// Save File From Cloudinary Url
	public function getCopyAndSave(){
		foreach ($this->imagesArr as $key => $file) {
			$this->copyFile($file);
			if($key == 5){
				//break;
			}
		}

		echo 'Success';
	}

	public function copyFile($file){
		$filename = $this->folderLocation.'/'.$file;
		$from = $this->baseUrl.$file;
		$d = get_headers($from);
		if($d[0] == 'HTTP/1.0 200 OK'){
			try{
				copy($from,$filename);	
			}catch(\Exception $e){
				$file1 = fopen("failed.txt","a");
				fwrite($file1,$file."\r\n");
				fclose($file1);
			}
		}else{
			$file1 = fopen("failed.txt","a");
			fwrite($file1,$file."\r\n");
			fclose($file1);
		}	
	}

}

$service = new CloudinaryImageCopy('outdoorswap_backup');
// $service->getCopyAndSave();